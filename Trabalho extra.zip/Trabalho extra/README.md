# TRABALHO EXTRA
•   Nesse é explicado uma técnica utilizando ponteiros para ponteiros que “simplifica” o código. Nesse link ele colocou o código,
    baixe o código e estude. Quem quiser ganhar 0,5 extra na cadeira faz um vídeo explicando o código.
    Vou colocar uma tarefa para envio no e-aulas. Faremos uma votação onde o autor do vídeo mais votado vai ganhar 1 ponto extra na cadeira.
Link do video: https://www.youtube.com/watch?v=0ZEX_l0DFK0&ab_channel=Computerphile




Link do Video referente a explicação do código: https://drive.google.com/file/d/13kcTdnxwVlahDClPvXp1lZDSSgKmBEu9/view?usp=sharing