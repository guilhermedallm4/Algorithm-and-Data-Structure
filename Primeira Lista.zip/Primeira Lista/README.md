# Exercico 1:
    Faça uma gravação curta de você criando um projeto "Olá
    Mundo" em C no Visual Code e usando o debug com um
    breakpoint no printf.
    
    Link do Video: https://drive.google.com/drive/folders/1m16ZlO6hXjsCZeZ9G3kkB8Qe-gXt6Hj0?usp=sharing

# Exercicio 2:
    Faça um programa que armazena nomes.
• O programa deve armazenar todos os nomes na mesma string.
• O tamanho da string deve crescer e diminuir conforme nomes
forem colocados ou removidos. Não pode ter desperdício de
memória.
• Faça o seguinte menu:
– 1) Adicionar nome
– 2) Remover nome
– 3) Listar
– 4) Sair

Link do Video: https://drive.google.com/drive/folders/1OlFfb-pkzqDsA0P9UYuCfYqYGNrQF8Ea?usp=sharing

# Exercicio 3:
    Faça uma agenda capaz de incluir, apagar, buscar e listar
quantas pessoas o usuário desejar, porém, toda a informação
incluída na agenda deve ficar num único lugar chamado: “void
*pBuffer”.
• Não pergunte para o usuário quantas pessoas ele vai incluir.
Não pode alocar espaço para mais pessoas do que o
necessário.
• Cada pessoa tem nome[10], idade e telefone.
• O trabalho que vale nota será uma continuação deste.

Link do Video:  https://drive.google.com/drive/folders/1r7RZOgcYlK_OpbH0D9hzk2vW-WF1TAI9?usp=sharing
